/**
 * Simple example client for the Role-Context MCP HTTP server
 * 
 * This example shows how to:
 * 1. Get all available roles
 * 2. Process a query with a specific role
 * 3. Create a custom role
 * 4. Process a query with the new custom role
 */

const axios = require('axios');

// Configuration
const API_URL = 'http://localhost:3000';

// Helper function to log responses nicely
function logResponse(title, data) {
  console.log('\n' + '='.repeat(50));
  console.log(title);
  console.log('='.repeat(50));
  console.log(JSON.stringify(data, null, 2));
}

async function runExample() {
  try {
    // Step 1: Check if the server is running
    console.log('Checking server health...');
    const healthResponse = await axios.get(`${API_URL}/health`);
    console.log(`Server status: ${healthResponse.data.status}`);
    
    // Step 2: Get all available roles
    console.log('\nFetching available roles...');
    const rolesResponse = await axios.get(`${API_URL}/roles`);
    const roles = rolesResponse.data.roles;
    logResponse('Available Roles:', roles.map(r => ({ id: r.id, name: r.name })));
    
    // Step 3: Process a query with the marketing expert role
    console.log('\nProcessing query with marketing expert role...');
    const marketingResponse = await axios.post(`${API_URL}/process`, {
      roleId: 'marketing-expert',
      query: 'What are the top 3 social media trends for small businesses?'
    });
    logResponse('Marketing Expert Response:', { response: marketingResponse.data.response });
    
    // Step 4: Create a custom role
    console.log('\nCreating a custom tech blogger role...');
    const createRoleResponse = await axios.post(`${API_URL}/roles`, {
      id: 'tech-blogger',
      name: 'Technology Blogger',
      description: 'Writes engaging content about technology trends and products',
      instructions: 'Create engaging, informative content about technology with a conversational tone',
      domains: ['technology', 'blogging', 'product-reviews', 'digital-trends'],
      tone: 'casual',
      systemPrompt: 'You are a popular technology blogger known for explaining complex tech concepts in simple terms. Your writing is engaging, informative, and slightly humorous.'
    });
    logResponse('New Role Created:', createRoleResponse.data.role);
    
    // Step 5: Process a query with the new custom role
    console.log('\nProcessing query with the new tech blogger role...');
    const techBloggerResponse = await axios.post(`${API_URL}/process`, {
      roleId: 'tech-blogger',
      query: 'Write a short intro paragraph about AI assistants for my blog'
    });
    logResponse('Tech Blogger Response:', { response: techBloggerResponse.data.response });
    
    // Step 6: Get available tone profiles
    console.log('\nFetching available tone profiles...');
    const tonesResponse = await axios.get(`${API_URL}/tones`);
    logResponse('Available Tone Profiles:', tonesResponse.data.tones);
    
    console.log('\nExample completed successfully!');
  } catch (error) {
    console.error('Error running example:');
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      console.error(`Status: ${error.response.status}`);
      console.error('Response:', error.response.data);
    } else if (error.request) {
      // The request was made but no response was received
      console.error('No response received from server. Is the server running?');
    } else {
      // Something happened in setting up the request that triggered an Error
      console.error('Error:', error.message);
    }
  }
}

// Run the example
console.log('Starting Role-Context MCP example client...');
console.log('Make sure the server is running with: npm run start:http');
runExample();

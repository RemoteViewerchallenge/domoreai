# Role-Specific Context MCP Server

A Model Context Protocol (MCP) server that defines and governs contextual boundaries based on agent roles in your system.

## Overview

This MCP server enables role-based context management for AI agents, allowing you to:

- Establish clear instructions, objectives, and domain knowledge for each AI agent (Marketing Expert, Songwriter, Executive Assistant, etc.)
- Keep role-relevant memory partitioned and scoped, preventing cross-contamination between different agent roles
- Adapt tone and style dynamically (serious, witty, sarcastic) per role, with tone profiles baked into the prompt

## Features

### Role Management

- Create, update, and delete custom roles
- Pre-defined roles with specific expertise domains
- Role-specific system prompts and instructions
- Customizable tone profiles

### Memory Management

- Role-specific memory storage
- Memory retrieval based on relevance to current query
- Time-to-live (TTL) for memories
- Memory limits per role

### MCP Integration

- Exposes roles as MCP resources
- Provides tools for role management and query processing
- Offers prompts for role-based interactions

## Getting Started

### Prerequisites

- Node.js 18+
- OpenAI API key

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/role-context-mcp.git
cd role-context-mcp

# Install dependencies
npm install

# Set up environment variables
echo "OPENAI_API_KEY=your_api_key_here" > .env

# Build the project
npm run build
```

### Running the Server

```bash
# Run the MCP server
npm start

# Run the HTTP server for testing
npm run start:http
```

### Configuration

The server can be configured by modifying `src/config.ts`. Key configuration options include:

- Default roles and their properties
- Available tone profiles
- Memory management settings
- OpenAI model selection

## MCP Integration

### Resources

The server exposes the following resources:

- `role://{roleId}` - Information about a specific role
- `role://tones` - Available tone profiles

### Tools

The server provides the following tools:

- `process-with-role` - Process a query using a specific role
- `create-role` - Create a new role
- `update-role` - Update an existing role
- `delete-role` - Delete a custom role
- `change-role-tone` - Change the tone of a role
- `store-memory` - Store a memory for a specific role
- `clear-role-memories` - Clear all memories for a role

### Prompts

The server provides the following prompts:

- `role-{roleId}` - Use a specific role to process a request
- `create-custom-role` - Create a new custom role

## Example Usage

### Processing a Query with a Role (MCP)

```typescript
// Example of using the process-with-role tool
const result = await client.executeToolRequest({
  name: 'process-with-role',
  parameters: {
    roleId: 'marketing-expert',
    query: 'How can I improve my social media engagement?',
    customInstructions: 'Focus on B2B strategies'
  }
});
```

### Processing a Query with a Role (HTTP API)

```typescript
// Example of using the HTTP API
const response = await axios.post('http://localhost:3000/process', {
  roleId: 'marketing-expert',
  query: 'How can I improve my social media engagement?',
  customInstructions: 'Focus on B2B strategies'
});

console.log(response.data.response);
```

### Creating a Custom Role

```typescript
// Example of using the create-role tool
const result = await client.executeToolRequest({
  name: 'create-role',
  parameters: {
    id: 'tech-writer',
    name: 'Technical Writer',
    description: 'Specializes in clear, concise technical documentation',
    instructions: 'Create documentation that is accessible to both technical and non-technical audiences',
    domains: ['technical-writing', 'documentation', 'tutorials'],
    tone: 'technical',
    systemPrompt: 'You are an experienced technical writer with expertise in creating clear, concise documentation for complex systems.'
  }
});
```

## License

MIT

import { Server } from "@modelcontextprotocol/sdk/server";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio";
import { RoleManager } from "./roles/roleManager";
import { MemoryManager } from "./memory/memoryManager";
import { OpenAIClient } from "./ai/openaiClient";
import { registerResourceHandlers } from "./handlers/resourceHandlers";
import { registerToolHandlers } from "./handlers/toolHandlers";
import { registerPromptHandlers } from "./handlers/promptHandlers";
import { config } from "./config";

async function main() {
  console.log("Starting Role-Specific Context MCP Server...");
  
  // Initialize core services
  const aiClient = new OpenAIClient(config.openai.apiKey, config.openai.model);
  const memoryManager = new MemoryManager();
  const roleManager = new RoleManager(memoryManager, aiClient);
  
  // Initialize server
  const server = new Server({
    name: "role-context-mcp",
    version: "1.0.0"
  }, {
    capabilities: {
      resources: {},
      tools: {},
      prompts: {}
    }
  });
  
  // Register handlers
  registerResourceHandlers(server, roleManager, memoryManager);
  registerToolHandlers(server, roleManager, memoryManager);
  registerPromptHandlers(server, roleManager);
  
  // Connect transport
  const transport = new StdioServerTransport();
  await server.connect(transport);
  
  console.log("Role-Specific Context MCP Server is running");
}

main().catch(error => {
  console.error("Fatal error:", error);
  process.exit(1);
});

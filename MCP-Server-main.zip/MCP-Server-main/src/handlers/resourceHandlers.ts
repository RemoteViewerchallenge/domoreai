import { Server } from "@modelcontextprotocol/sdk/server";
import { RoleManager } from "../roles/roleManager";
import { MemoryManager } from "../memory/memoryManager";
import { VectorMemory } from '../memory/types';

/**
 * Register all resource-related handlers
 */
export function registerResourceHandlers(
  server: Server,
  roleManager: RoleManager,
  memoryManager: MemoryManager
): void {
  // List available resources
  server.setRequestHandler('resources/list', async () => {
    const roles = roleManager.getAllRoles();
    
    // Convert roles to resources
    const resources = roles.map(role => ({
      uri: `role://${role.id}`,
      name: role.name,
      description: role.description
    }));
    
    // Add special resources
    resources.push({
      uri: 'role://tones',
      name: 'Available Tone Profiles',
      description: 'List of available tone profiles for roles'
    });
    
    return { resources };
  });
  
  // Get resource content
  server.setRequestHandler('resources/get', async (request) => {
    const { uri } = request.params;
    
    // Handle role resources
    if (uri.startsWith('role://')) {
      const resourceId = uri.replace('role://', '');
      
      // Special case for tone profiles
      if (resourceId === 'tones') {
        const toneProfiles = roleManager.getAllToneProfiles();
        const content = Array.from(toneProfiles.entries())
          .map(([tone, profile]) => `## ${tone}\n${profile.description}\n\n${profile.modifiers}`)
          .join('\n\n');
          
        return {
          content: {
            type: 'text',
            text: `# Available Tone Profiles\n\n${content}`
          }
        };
      }
      
      // Handle specific role
      const role = roleManager.getRole(resourceId);
      if (!role) {
        throw new Error(`Resource not found: ${uri}`);
      }
      
      // Get role memories
      const memories = await memoryManager.getMemoriesByRole(role.id);
      const recentMemories = memories
        .slice(0, 10) // Limit to 10 most recent memories
        .map((memory: VectorMemory) => `- ${memory.content} (${new Date(memory.timestamp).toLocaleString()})`)
        .join('\n');
      
      // Format role information
      const roleContent = `# ${role.name}\n\n` +
        `## Description\n${role.description}\n\n` +
        `## Instructions\n${role.instructions}\n\n` +
        `## Domains\n${role.domains.join(', ')}\n\n` +
        `## Tone\n${role.tone}\n\n` +
        `## System Prompt\n${role.systemPrompt}\n\n` +
        (role.customInstructions ? `## Custom Instructions\n${role.customInstructions}\n\n` : '') +
        (recentMemories ? `## Recent Memories\n${recentMemories}` : 'No recent memories');
      
      return {
        content: {
          type: 'text',
          text: roleContent
        }
      };
    }
    
    throw new Error(`Unsupported resource URI: ${uri}`);
  });
}

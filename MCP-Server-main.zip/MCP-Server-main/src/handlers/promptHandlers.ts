import { Server } from "@modelcontextprotocol/sdk/server";
import { RoleManager } from "../roles/roleManager.js";

/**
 * Register all prompt-related handlers
 */
export function registerPromptHandlers(
  server: Server,
  roleManager: RoleManager
): void {
  // List available prompts
  server.setRequestHandler('prompts/list', async () => {
    const roles = roleManager.getAllRoles();
    
    // Create a prompt for each role
    const prompts = roles.map(role => ({
      name: `role-${role.id}`,
      description: `Use the ${role.name} role to process your request`,
      arguments: [
        {
          name: 'query',
          description: 'Your request or question',
          required: true
        },
        {
          name: 'customInstructions',
          description: 'Optional additional instructions',
          required: false
        }
      ]
    }));
    
    // Add special prompts
    prompts.push({
      name: 'create-custom-role',
      description: 'Create a new custom role with specific expertise and tone',
      arguments: [
        {
          name: 'name',
          description: 'Name for the new role',
          required: true
        },
        {
          name: 'expertise',
          description: 'Areas of expertise for this role',
          required: true
        },
        {
          name: 'tone',
          description: 'Tone style (professional, creative, casual, technical, witty, formal)',
          required: true
        }
      ]
    });
    
    return { prompts };
  });
  
  // Get specific prompt
  server.setRequestHandler('prompts/get', async (request) => {
    const { name, arguments: args } = request.params;
    
    // Handle role-specific prompts
    if (name.startsWith('role-')) {
      const roleId = name.replace('role-', '');
      const role = roleManager.getRole(roleId);
      
      if (!role) {
        throw new Error(`Role not found: ${roleId}`);
      }
      
      const query = args?.query || '';
      const customInstructions = args?.customInstructions;
      
      // Generate the complete system prompt
      const systemPrompt = roleManager.generateCompletePrompt(roleId, customInstructions);
      
      return {
        messages: [
          {
            role: 'system',
            content: {
              type: 'text',
              text: systemPrompt
            }
          },
          {
            role: 'user',
            content: {
              type: 'text',
              text: query
            }
          }
        ]
      };
    }
    
    // Handle create-custom-role prompt
    if (name === 'create-custom-role') {
      const roleName = args?.name || '';
      const expertise = args?.expertise || '';
      const tone = args?.tone || 'professional';
      
      return {
        messages: [
          {
            role: 'system',
            content: {
              type: 'text',
              text: 'You are a helpful assistant that helps users create custom AI roles with specific expertise and tone.'
            }
          },
          {
            role: 'user',
            content: {
              type: 'text',
              text: `I want to create a new role with the following specifications:\n\n` +
                `- Name: ${roleName}\n` +
                `- Expertise: ${expertise}\n` +
                `- Tone: ${tone}\n\n` +
                `Please help me define this role with appropriate system instructions, domain knowledge, and tone settings.`
            }
          }
        ]
      };
    }
    
    throw new Error(`Prompt not found: ${name}`);
  });
}

import { Server } from "@modelcontextprotocol/sdk/server";
import { RoleManager } from "../roles/roleManager.js";
import { MemoryManager } from "../memory/memoryManager.js";

/**
 * Register all tool-related handlers
 */
export function registerToolHandlers(
  server: Server,
  roleManager: RoleManager,
  memoryManager: MemoryManager
): void {
  // List available tools
  server.setRequestHandler('tools/list', async () => {
    return {
      tools: [
        {
          name: 'process-with-role',
          description: 'Process a query using a specific role',
          parameters: {
            type: 'object',
            properties: {
              roleId: {
                type: 'string',
                description: 'ID of the role to use'
              },
              query: {
                type: 'string',
                description: 'The query to process'
              },
              customInstructions: {
                type: 'string',
                description: 'Optional custom instructions for this query'
              }
            },
            required: ['roleId', 'query']
          }
        },
        {
          name: 'create-role',
          description: 'Create a new role',
          parameters: {
            type: 'object',
            properties: {
              id: {
                type: 'string',
                description: 'Unique ID for the role'
              },
              name: {
                type: 'string',
                description: 'Display name for the role'
              },
              description: {
                type: 'string',
                description: 'Description of the role'
              },
              instructions: {
                type: 'string',
                description: 'Specific instructions for the role'
              },
              domains: {
                type: 'array',
                items: {
                  type: 'string'
                },
                description: 'Domains of expertise for this role'
              },
              tone: {
                type: 'string',
                description: 'Tone profile to use (professional, creative, etc.)'
              },
              systemPrompt: {
                type: 'string',
                description: 'Base system prompt for the role'
              },
              customInstructions: {
                type: 'string',
                description: 'Optional custom instructions'
              }
            },
            required: ['id', 'name', 'description', 'instructions', 'domains', 'tone', 'systemPrompt']
          }
        },
        {
          name: 'update-role',
          description: 'Update an existing role',
          parameters: {
            type: 'object',
            properties: {
              roleId: {
                type: 'string',
                description: 'ID of the role to update'
              },
              updates: {
                type: 'object',
                description: 'Fields to update'
              }
            },
            required: ['roleId', 'updates']
          }
        },
        {
          name: 'delete-role',
          description: 'Delete a custom role',
          parameters: {
            type: 'object',
            properties: {
              roleId: {
                type: 'string',
                description: 'ID of the role to delete'
              }
            },
            required: ['roleId']
          }
        },
        {
          name: 'change-role-tone',
          description: 'Change the tone of a role',
          parameters: {
            type: 'object',
            properties: {
              roleId: {
                type: 'string',
                description: 'ID of the role to update'
              },
              tone: {
                type: 'string',
                description: 'New tone to apply'
              }
            },
            required: ['roleId', 'tone']
          }
        },
        {
          name: 'store-memory',
          description: 'Store a memory for a specific role',
          parameters: {
            type: 'object',
            properties: {
              roleId: {
                type: 'string',
                description: 'ID of the role'
              },
              content: {
                type: 'string',
                description: 'Memory content'
              },
              metadata: {
                type: 'object',
                description: 'Additional metadata'
              },
              ttl: {
                type: 'number',
                description: 'Time-to-live in milliseconds (optional)'
              }
            },
            required: ['roleId', 'content']
          }
        },
        {
          name: 'clear-role-memories',
          description: 'Clear all memories for a role',
          parameters: {
            type: 'object',
            properties: {
              roleId: {
                type: 'string',
                description: 'ID of the role'
              }
            },
            required: ['roleId']
          }
        }
      ]
    };
  });

  // Execute tools
  server.setRequestHandler('tools/execute', async (request) => {
    const { name, parameters } = request.params;

    switch (name) {
      case 'process-with-role': {
        const { roleId, query, customInstructions } = parameters;
        const response = await roleManager.processQuery(roleId, query, customInstructions);
        return {
          result: {
            type: 'text',
            text: response
          }
        };
      }

      case 'create-role': {
        const role = roleManager.createRole(parameters);
        return {
          result: {
            type: 'text',
            text: `Role created: ${role.name} (${role.id})`
          }
        };
      }

      case 'update-role': {
        const { roleId, updates } = parameters;
        const role = roleManager.updateRole(roleId, updates);
        return {
          result: {
            type: 'text',
            text: `Role updated: ${role.name} (${role.id})`
          }
        };
      }

      case 'delete-role': {
        const { roleId } = parameters;
        const deleted = roleManager.deleteRole(roleId);
        return {
          result: {
            type: 'text',
            text: deleted ? `Role deleted: ${roleId}` : `Role not found: ${roleId}`
          }
        };
      }

      case 'change-role-tone': {
        const { roleId, tone } = parameters;
        const role = roleManager.changeRoleTone(roleId, tone);
        return {
          result: {
            type: 'text',
            text: `Role tone changed: ${role.name} now uses '${tone}' tone`
          }
        };
      }

      case 'store-memory': {
        const { roleId, content, metadata = {}, ttl } = parameters;
        const memory = await memoryManager.storeMemory({
          roleId,
          content,
          timestamp: Date.now(),
          metadata,
          ttl
        });
        return {
          result: {
            type: 'text',
            text: `Memory stored: ${memory.id}`
          }
        };
      }

      case 'clear-role-memories': {
        const { roleId } = parameters;
        const count = memoryManager.clearRoleMemories(roleId);
        return {
          result: {
            type: 'text',
            text: `Cleared ${count} memories for role: ${roleId}`
          }
        };
      }

      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  });
}

import { Server } from "@modelcontextprotocol/sdk/server";
import { ContextManager } from "../context/contextManager";
import { ContextType, ContextPriority } from "../context/types";

/**
 * Register all context-related handlers
 */
export function registerContextHandlers(
  server: Server,
  contextManager: ContextManager
): void {
  // List available context tools
  server.setRequestHandler('tools/list', async (request) => {
    const tools: any[] = [];
    
    return {
      tools: [
        ...tools,
        {
          name: 'switch-context',
          description: 'Switch context for an agent',
          parameters: {
            type: 'object',
            properties: {
              agentId: {
                type: 'string',
                description: 'ID of the agent'
              },
              contextType: {
                type: 'string',
                enum: Object.values(ContextType),
                description: 'Type of context to switch'
              },
              contextValue: {
                type: 'string',
                description: 'New context value'
              },
              priority: {
                type: 'string',
                enum: Object.values(ContextPriority),
                description: 'Priority level for this context'
              },
              metadata: {
                type: 'object',
                description: 'Additional metadata for the context'
              }
            },
            required: ['agentId', 'contextType', 'contextValue']
          }
        },
        {
          name: 'get-current-context',
          description: 'Get current context for an agent',
          parameters: {
            type: 'object',
            properties: {
              agentId: {
                type: 'string',
                description: 'ID of the agent'
              }
            },
            required: ['agentId']
          }
        },
        {
          name: 'get-context-history',
          description: 'Get context history for an agent',
          parameters: {
            type: 'object',
            properties: {
              agentId: {
                type: 'string',
                description: 'ID of the agent'
              }
            },
            required: ['agentId']
          }
        },
        {
          name: 'add-context-trigger',
          description: 'Add a new context trigger',
          parameters: {
            type: 'object',
            properties: {
              pattern: {
                type: 'string',
                description: 'Pattern to match (string or regex)'
              },
              contextType: {
                type: 'string',
                enum: Object.values(ContextType),
                description: 'Type of context to switch when triggered'
              },
              contextValue: {
                type: 'string',
                description: 'Context value to set when triggered'
              },
              description: {
                type: 'string',
                description: 'Description of this trigger'
              }
            },
            required: ['pattern', 'contextType', 'contextValue', 'description']
          }
        },
        {
          name: 'update-context-trigger',
          description: 'Update an existing context trigger',
          parameters: {
            type: 'object',
            properties: {
              triggerId: {
                type: 'string',
                description: 'ID of the trigger to update'
              },
              updates: {
                type: 'object',
                description: 'Fields to update'
              }
            },
            required: ['triggerId', 'updates']
          }
        },
        {
          name: 'delete-context-trigger',
          description: 'Delete a context trigger',
          parameters: {
            type: 'object',
            properties: {
              triggerId: {
                type: 'string',
                description: 'ID of the trigger to delete'
              }
            },
            required: ['triggerId']
          }
        },
        {
          name: 'check-input-for-triggers',
          description: 'Check input for context triggers and apply if matched',
          parameters: {
            type: 'object',
            properties: {
              agentId: {
                type: 'string',
                description: 'ID of the agent'
              },
              input: {
                type: 'string',
                description: 'Input to check for triggers'
              }
            },
            required: ['agentId', 'input']
          }
        },
        {
          name: 'handle-multi-modal-context',
          description: 'Handle multi-modal context',
          parameters: {
            type: 'object',
            properties: {
              agentId: {
                type: 'string',
                description: 'ID of the agent'
              },
              text: {
                type: 'string',
                description: 'Text context'
              },
              imageUrls: {
                type: 'array',
                items: {
                  type: 'string'
                },
                description: 'URLs of images to include in context'
              },
              priority: {
                type: 'string',
                enum: Object.values(ContextPriority),
                description: 'Priority level for this context'
              },
              metadata: {
                type: 'object',
                description: 'Additional metadata'
              }
            },
            required: ['agentId', 'priority']
          }
        }
      ]
    };
  });

  // Execute context tools
  server.setRequestHandler('tools/execute', async (request) => {
    const { name, parameters } = request.params;

    switch (name) {
      case 'switch-context': {
        const { agentId, contextType, contextValue, priority, metadata } = parameters;
        const response = await contextManager.switchContext({
          agentId,
          contextType,
          contextValue,
          priority,
          metadata
        });
        
        return {
          result: {
            type: 'json',
            json: response
          }
        };
      }

      case 'get-current-context': {
        const { agentId } = parameters;
        const context = contextManager.getCurrentContext(agentId);
        
        return {
          result: {
            type: 'json',
            json: context
          }
        };
      }

      case 'get-context-history': {
        const { agentId } = parameters;
        const history = contextManager.getContextHistory(agentId);
        
        return {
          result: {
            type: 'json',
            json: history
          }
        };
      }

      case 'add-context-trigger': {
        const trigger = contextManager.addContextTrigger(parameters);
        
        return {
          result: {
            type: 'json',
            json: trigger
          }
        };
      }

      case 'update-context-trigger': {
        const { triggerId, updates } = parameters;
        const trigger = contextManager.updateContextTrigger(triggerId, updates);
        
        return {
          result: {
            type: 'json',
            json: trigger
          }
        };
      }

      case 'delete-context-trigger': {
        const { triggerId } = parameters;
        const success = contextManager.deleteContextTrigger(triggerId);
        
        return {
          result: {
            type: 'text',
            text: success ? `Trigger deleted: ${triggerId}` : `Trigger not found: ${triggerId}`
          }
        };
      }

      case 'check-input-for-triggers': {
        const { agentId, input } = parameters;
        const responses = await contextManager.checkAndApplyTriggers(agentId, input);
        
        return {
          result: {
            type: 'json',
            json: responses
          }
        };
      }

      case 'handle-multi-modal-context': {
        const { agentId, text, imageUrls, priority, metadata } = parameters;
        await contextManager.handleMultiModalContext(agentId, {
          text,
          imageUrls,
          priority: priority || ContextPriority.MEDIUM,
          metadata: metadata || {}
        });
        
        return {
          result: {
            type: 'text',
            text: 'Multi-modal context handled successfully'
          }
        };
      }
      
      default:
        return undefined; // Let other handlers process this tool
    }
  });

  // Add context-aware prompt modifications
  server.setRequestHandler('prompts/generate', async (request) => {
    const { agentId } = request.params;
    if (!agentId) {
      return undefined;
    }
    
    // Get context modifiers
    const contextModifiers = contextManager.generateContextPromptModifiers(agentId);
    
    // Return the context modifiers
    return {
      prompt: contextModifiers
    };
  });
}

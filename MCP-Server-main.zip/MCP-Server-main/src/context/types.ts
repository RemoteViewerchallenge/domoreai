// Types for Real-Time Context Switching MCP

// Context types
export enum ContextType {
  TONE = 'tone',
  TASK = 'task',
  ROLE = 'role',
  DOMAIN = 'domain',
  USER = 'user',
  ENVIRONMENT = 'environment',
  MULTIMODAL = 'multimodal'
}

// Context priority levels
export enum ContextPriority {
  HIGH = 'high',
  MEDIUM = 'medium',
  LOW = 'low',
  SUSPENDED = 'suspended'
}

// Context state
export interface ContextState {
  id: string;
  type: ContextType;
  value: string;
  priority: ContextPriority;
  metadata?: Record<string, any>;
  createdAt: number;
  updatedAt: number;
}

// Context trigger
export interface ContextTrigger {
  id: string;
  pattern: string | RegExp;
  contextType: ContextType;
  contextValue: string;
  description: string;
  isActive: boolean;
}

// Context switch request
export interface ContextSwitchRequest {
  agentId: string;
  contextType: ContextType;
  contextValue: string;
  priority?: ContextPriority;
  metadata?: Record<string, any>;
  triggerId?: string; // If triggered by a predefined trigger
}

// Context switch response
export interface ContextSwitchResponse {
  success: boolean;
  message: string;
  previousContext?: ContextState;
  newContext?: ContextState;
}

// Context stack - maintains history of context changes
export interface ContextStack {
  agentId: string;
  stack: ContextState[];
  current: Record<ContextType, ContextState>;
}

// Multi-modal context
export interface MultiModalContext {
  text?: string;
  imageUrls?: string[];
  metadata?: Record<string, any>;
  priority: ContextPriority;
}

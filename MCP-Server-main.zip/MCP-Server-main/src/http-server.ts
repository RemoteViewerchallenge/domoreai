import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { RoleManager } from './roles/roleManager';
import { MemoryManager } from './memory/memoryManager';
import { OpenAIClient } from './ai/openaiClient';
import { config } from './config';

// Load environment variables
dotenv.config();

// Initialize core services
const aiClient = new OpenAIClient(config.openai.apiKey, config.openai.model);
const memoryManager = new MemoryManager();
const roleManager = new RoleManager(memoryManager, aiClient);

// Create Express app
const app = express();
app.use(cors());
app.use(express.json());

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', server: 'role-context-mcp' });
});

// Get all roles
app.get('/roles', (req, res) => {
  try {
    const roles = roleManager.getAllRoles();
    res.json({ roles });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Get a specific role
app.get('/roles/:roleId', (req, res) => {
  try {
    const role = roleManager.getRole(req.params.roleId);
    if (!role) {
      return res.status(404).json({ error: `Role with ID ${req.params.roleId} not found` });
    }
    res.json({ role });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Create a new role
app.post('/roles', (req, res) => {
  try {
    const role = roleManager.createRole(req.body);
    res.status(201).json({ role });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Update a role
app.patch('/roles/:roleId', (req, res) => {
  try {
    const role = roleManager.updateRole(req.params.roleId, req.body);
    res.json({ role });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Delete a role
app.delete('/roles/:roleId', (req, res) => {
  try {
    const deleted = roleManager.deleteRole(req.params.roleId);
    if (!deleted) {
      return res.status(404).json({ error: `Role with ID ${req.params.roleId} not found` });
    }
    res.json({ success: true });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Process a query with a specific role
app.post('/process', async (req, res) => {
  try {
    const { roleId, query, customInstructions } = req.body;
    
    if (!roleId || !query) {
      return res.status(400).json({ error: 'roleId and query are required' });
    }
    
    const response = await roleManager.processQuery(roleId, query, customInstructions);
    res.json({ response });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Get tone profiles
app.get('/tones', (req, res) => {
  try {
    const tones = roleManager.getAllToneProfiles();
    res.json({ tones: Object.fromEntries(tones) });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Role-Specific Context HTTP Server running on port ${PORT}`);
});

import OpenAI from 'openai';

export class OpenAIClient {
  private client: OpenAI;
  private model: string;

  constructor(apiKey: string, model: string = 'gpt-4o-mini') {
    this.client = new OpenAI({
      apiKey: apiKey
    });
    this.model = model;
  }

  /**
   * Generate a response using the OpenAI API
   */
  public async generateResponse(
    systemPrompt: string,
    userQuery: string,
    contextMemories: string = ''
  ): Promise<string> {
    try {
      const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
        {
          role: 'system',
          content: systemPrompt
        }
      ];

      // Add context memories if available
      if (contextMemories) {
        messages.push({
          role: 'system',
          content: contextMemories
        });
      }

      // Add user query
      messages.push({
        role: 'user',
        content: userQuery
      });

      const response = await this.client.chat.completions.create({
        model: this.model,
        messages,
        temperature: 0.7,
        max_tokens: 1000
      });

      return response.choices[0]?.message?.content || 'No response generated.';
    } catch (error: unknown) {
      console.error('Error generating response:', error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      throw new Error(`Failed to generate response: ${errorMessage}`);
    }
  }

  /**
   * Generate embeddings for text
   */
  public async generateEmbedding(text: string): Promise<number[]> {
    try {
      const response = await this.client.embeddings.create({
        model: 'text-embedding-3-small',
        input: text
      });

      return response.data[0].embedding;
    } catch (error: unknown) {
      console.error('Error generating embedding:', error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      throw new Error(`Failed to generate embedding: ${errorMessage}`);
    }
  }
}

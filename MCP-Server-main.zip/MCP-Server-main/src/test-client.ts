import { createClient } from '@modelcontextprotocol/sdk/client';

async function main() {
  try {
    console.log('Connecting to Role-Specific Context MCP Server...');
    
    // Create MCP client
    const client = await createClient({
      transport: 'stdio',
      serverCommand: 'npm run start',
      serverCwd: process.cwd(),
    });
    
    // Get server info
    const serverInfo = await client.getServerInfo();
    console.log('Connected to server:', serverInfo);
    
    // List available resources
    const resources = await client.listResources();
    console.log('\nAvailable resources:', resources);
    
    // List available tools
    const tools = await client.listTools();
    console.log('\nAvailable tools:', JSON.stringify(tools, null, 2));
    
    // Test a tool: process query with marketing expert role
    console.log('\nTesting process-with-role tool with marketing-expert role...');
    const marketingResponse = await client.executeToolRequest({
      name: 'process-with-role',
      parameters: {
        roleId: 'marketing-expert',
        query: 'How can I improve my social media engagement?'
      }
    });
    console.log('Marketing Expert Response:', marketingResponse);
    
    // Test a tool: process query with songwriter role
    console.log('\nTesting process-with-role tool with songwriter role...');
    const songwriterResponse = await client.executeToolRequest({
      name: 'process-with-role',
      parameters: {
        roleId: 'songwriter',
        query: 'Help me write a chorus about overcoming challenges'
      }
    });
    console.log('Songwriter Response:', songwriterResponse);
    
    // Test creating a custom role
    console.log('\nTesting create-role tool...');
    const createRoleResponse = await client.executeToolRequest({
      name: 'create-role',
      parameters: {
        id: 'tech-writer',
        name: 'Technical Writer',
        description: 'Specializes in clear, concise technical documentation',
        instructions: 'Create documentation that is accessible to both technical and non-technical audiences',
        domains: ['technical-writing', 'documentation', 'tutorials'],
        tone: 'technical',
        systemPrompt: 'You are an experienced technical writer with expertise in creating clear, concise documentation for complex systems.'
      }
    });
    console.log('Create Role Response:', createRoleResponse);
    
    // Test the newly created role
    console.log('\nTesting process-with-role tool with the new tech-writer role...');
    const techWriterResponse = await client.executeToolRequest({
      name: 'process-with-role',
      parameters: {
        roleId: 'tech-writer',
        query: 'How should I structure API documentation?'
      }
    });
    console.log('Tech Writer Response:', techWriterResponse);
    
    // Close the client
    await client.close();
    console.log('\nTest completed successfully!');
  } catch (error) {
    console.error('Error testing MCP server:', error);
    process.exit(1);
  }
}

main();

import { config } from "../config";
import { ImportanceLevel, MemoryProvider, MemorySearchParams, MemoryStorageParams, MemoryType, VectorMemory } from "./types";
import { MemoryProviderFactory } from "./providers/providerFactory";

/**
 * Memory manager for the Long-Term Memory Context MCP
 * Manages different types of memories with vector search capabilities
 */
export class MemoryManager {
  private provider: MemoryProvider;

  constructor() {
    // Initialize the memory provider
    this.provider = MemoryProviderFactory.createProvider();
    
    // Set up periodic cleanup of expired memories
    setInterval(() => this.provider.clearExpiredMemories(), 60 * 60 * 1000); // Run every hour
  }

  /**
   * Store a new memory for a role
   */
  public async storeMemory(params: MemoryStorageParams): Promise<VectorMemory> {
    return this.provider.storeMemory(params);
  }

  /**
   * Store a session memory (short-term)
   */
  public async storeSessionMemory(roleId: string, content: string, metadata: Record<string, any> = {}, sessionId?: string): Promise<VectorMemory> {
    return this.storeMemory({
      roleId,
      content,
      type: MemoryType.SESSION,
      importance: ImportanceLevel.HIGH,
      metadata,
      sessionId
    });
  }

  /**
   * Store a user memory (medium-term)
   */
  public async storeUserMemory(roleId: string, content: string, metadata: Record<string, any> = {}, userId?: string): Promise<VectorMemory> {
    return this.storeMemory({
      roleId,
      content,
      type: MemoryType.USER,
      importance: ImportanceLevel.MEDIUM,
      metadata,
      userId
    });
  }

  /**
   * Store a knowledge memory (long-term)
   */
  public async storeKnowledgeMemory(roleId: string, content: string, metadata: Record<string, any> = {}): Promise<VectorMemory> {
    return this.storeMemory({
      roleId,
      content,
      type: MemoryType.KNOWLEDGE,
      importance: ImportanceLevel.LOW,
      metadata
    });
  }

  /**
   * Get all memories for a specific role
   */
  public async getMemoriesByRole(roleId: string, type?: MemoryType): Promise<VectorMemory[]> {
    return this.provider.getMemoriesByRole(roleId, type);
  }

  /**
   * Get a specific memory by ID
   */
  public async getMemory(id: string): Promise<VectorMemory | null> {
    return this.provider.getMemory(id);
  }

  /**
   * Delete a specific memory
   */
  public async deleteMemory(id: string): Promise<boolean> {
    return this.provider.deleteMemory(id);
  }

  /**
   * Clear all memories for a specific role
   */
  public async clearRoleMemories(roleId: string, type?: MemoryType): Promise<number> {
    return this.provider.clearRoleMemories(roleId, type);
  }

  /**
   * Clear session memories for a specific role
   */
  public async clearSessionMemories(roleId: string, sessionId?: string): Promise<number> {
    if (sessionId) {
      // Clear only memories for this session
      let count = 0;
      const memories = await this.provider.getMemoriesByRole(roleId, MemoryType.SESSION);
      for (const memory of memories) {
        if (memory.sessionId === sessionId && memory.id) {
          await this.provider.deleteMemory(memory.id);
          count++;
        }
      }
      return count;
    } else {
      // Clear all session memories for this role
      return this.provider.clearRoleMemories(roleId, MemoryType.SESSION);
    }
  }

  /**
   * Get relevant memories for a role and query using semantic search
   */
  public async getRelevantMemories(params: MemorySearchParams): Promise<VectorMemory[]> {
    return this.provider.searchMemories(params);
  }

  /**
   * Get relevant memories across all memory types
   */
  public async getAllRelevantMemories(roleId: string, query: string, limit: number = 10): Promise<VectorMemory[]> {
    return this.getRelevantMemories({
      roleId,
      query,
      limit
    });
  }

  /**
   * Get relevant session memories
   */
  public async getRelevantSessionMemories(roleId: string, query: string, sessionId?: string, limit: number = 5): Promise<VectorMemory[]> {
    return this.getRelevantMemories({
      roleId,
      query,
      type: MemoryType.SESSION,
      sessionId,
      limit
    });
  }

  /**
   * Get relevant user memories
   */
  public async getRelevantUserMemories(roleId: string, query: string, userId?: string, limit: number = 5): Promise<VectorMemory[]> {
    return this.getRelevantMemories({
      roleId,
      query,
      type: MemoryType.USER,
      userId,
      limit
    });
  }

  /**
   * Get relevant knowledge memories
   */
  public async getRelevantKnowledgeMemories(roleId: string, query: string, limit: number = 5): Promise<VectorMemory[]> {
    return this.getRelevantMemories({
      roleId,
      query,
      type: MemoryType.KNOWLEDGE,
      limit
    });
  }

  /**
   * Format memories for inclusion in a prompt
   */
  public formatMemoriesForPrompt(memories: VectorMemory[]): string {
    if (memories.length === 0) {
      return '';
    }

    interface MemorySections {
      [key: string]: VectorMemory[];
    }
    
    const sections: MemorySections = {
      [MemoryType.SESSION]: [],
      [MemoryType.USER]: [],
      [MemoryType.KNOWLEDGE]: []
    };

    // Group memories by type
    for (const memory of memories) {
      if (sections[memory.type]) {
        sections[memory.type].push(memory);
      }
    }

    let result = "### Relevant Context\n\n";

    // Add session memories
    if (sections[MemoryType.SESSION].length > 0) {
      result += "#### Recent Conversation\n";
      for (const memory of sections[MemoryType.SESSION]) {
        result += `- ${memory.content}\n`;
      }
      result += "\n";
    }

    // Add user memories
    if (sections[MemoryType.USER].length > 0) {
      result += "#### User Information\n";
      for (const memory of sections[MemoryType.USER]) {
        result += `- ${memory.content}\n`;
      }
      result += "\n";
    }

    // Add knowledge memories
    if (sections[MemoryType.KNOWLEDGE].length > 0) {
      result += "#### Knowledge Base\n";
      for (const memory of sections[MemoryType.KNOWLEDGE]) {
        result += `- ${memory.content}\n`;
      }
      result += "\n";
    }

    return result;
  }
}

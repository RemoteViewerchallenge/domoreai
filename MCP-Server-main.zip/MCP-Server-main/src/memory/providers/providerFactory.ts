import { MemoryProvider } from '../types';
import { InMemoryProvider } from './inMemoryProvider';
import { SupabaseMemoryProvider } from './supabaseProvider';
import { config } from '../../config';

/**
 * Factory for creating memory providers
 */
export class MemoryProviderFactory {
  /**
   * Create a memory provider based on configuration
   */
  public static createProvider(): MemoryProvider {
    // Check if Supabase is configured
    if (config.supabase.url && config.supabase.key) {
      try {
        return new SupabaseMemoryProvider();
      } catch (error) {
        console.warn('Failed to initialize Supabase provider, falling back to in-memory provider:', error);
      }
    }
    
    // Fall back to in-memory provider
    return new InMemoryProvider();
  }
}

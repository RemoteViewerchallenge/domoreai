// Memory types and interfaces for the Long-Term Memory Context MCP

// Memory types
export enum MemoryType {
  SESSION = 'session',
  USER = 'user',
  KNOWLEDGE = 'knowledge'
}

// Memory importance levels
export enum ImportanceLevel {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high'
}

// Base memory interface
export interface BaseMemory {
  id?: string;  // Auto-generated if not provided
  roleId: string;
  content: string;
  timestamp: number;
  metadata: Record<string, any>;
  ttl?: number;  // Time-to-live in milliseconds
  type: MemoryType;
  importance: ImportanceLevel;
  userId?: string; // Optional user identifier for user-specific memories
  sessionId?: string; // Optional session identifier for session-specific memories
}

// Memory with vector embedding
export interface VectorMemory extends BaseMemory {
  embedding?: number[];
  vectorId?: string; // ID in the vector database
}

// Memory search parameters
export interface MemorySearchParams {
  roleId: string;
  query: string;
  type?: MemoryType;
  userId?: string;
  sessionId?: string;
  limit?: number;
  minRelevanceScore?: number;
}

// Memory storage parameters
export interface MemoryStorageParams {
  roleId: string;
  content: string;
  type: MemoryType;
  importance?: ImportanceLevel;
  metadata?: Record<string, any>;
  ttl?: number;
  userId?: string;
  sessionId?: string;
}

// Memory provider interface
export interface MemoryProvider {
  storeMemory(params: MemoryStorageParams): Promise<VectorMemory>;
  getMemory(id: string): Promise<VectorMemory | null>;
  deleteMemory(id: string): Promise<boolean>;
  searchMemories(params: MemorySearchParams): Promise<VectorMemory[]>;
  getMemoriesByRole(roleId: string, type?: MemoryType): Promise<VectorMemory[]>;
  clearRoleMemories(roleId: string, type?: MemoryType): Promise<number>;
  clearExpiredMemories(): Promise<number>;
}

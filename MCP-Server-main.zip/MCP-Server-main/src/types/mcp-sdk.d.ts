// Type definitions for @modelcontextprotocol/sdk

declare module '@modelcontextprotocol/sdk/server' {
  export interface ServerOptions {
    name: string;
    version: string;
  }

  export interface ServerCapabilities {
    capabilities: {
      resources?: Record<string, any>;
      tools?: Record<string, any>;
      prompts?: Record<string, any>;
    };
  }

  export class Server {
    constructor(options: ServerOptions, capabilities: ServerCapabilities);
    setRequestHandler(method: string, handler: (request: any) => Promise<any>): void;
    connect(transport: any): Promise<void>;
  }
}

declare module '@modelcontextprotocol/sdk/server/stdio' {
  export class StdioServerTransport {
    constructor();
  }
}

declare module '@modelcontextprotocol/sdk/client' {
  export interface ClientOptions {
    transport: 'stdio' | 'http';
    serverCommand?: string;
    serverCwd?: string;
    url?: string;
  }

  export interface MCPClient {
    getServerInfo(): Promise<any>;
    listResources(): Promise<any>;
    getResource(uri: string): Promise<any>;
    listTools(): Promise<any>;
    executeToolRequest(request: { name: string; parameters: Record<string, any> }): Promise<any>;
    listPrompts(): Promise<any>;
    getPrompt(name: string, args?: Record<string, any>): Promise<any>;
    close(): Promise<void>;
  }

  export function createClient(options: ClientOptions): Promise<MCPClient>;
}

// Configuration for the Role-Specific Context MCP Server
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

export const config = {
  openai: {
    apiKey: process.env.OPENAI_API_KEY || "",
    model: process.env.OPENAI_MODEL || "gpt-4o-mini",
    embeddingModel: process.env.OPENAI_EMBEDDING_MODEL || "text-embedding-3-small"
  },
  supabase: {
    url: process.env.SUPABASE_URL || "",
    key: process.env.SUPABASE_KEY || "",
    vectorCollection: process.env.SUPABASE_VECTOR_COLLECTION || "memories"
  },
  roles: {
    // Default roles available in the system
    defaults: [
      {
        id: "marketing-expert",
        name: "Marketing Expert",
        description: "Specializes in marketing strategy, branding, and campaign development",
        instructions: "Provide expert marketing advice with a focus on ROI and measurable outcomes.",
        domains: ["marketing", "advertising", "branding", "social-media"],
        tone: "professional",
        systemPrompt: "You are an expert marketing consultant with 15+ years of experience across digital and traditional channels. Focus on data-driven strategies and practical advice that can be implemented immediately."
      },
      {
        id: "songwriter",
        name: "Songwriter",
        description: "Creates lyrics and musical compositions across various genres",
        instructions: "Develop creative and emotionally resonant song lyrics and musical direction.",
        domains: ["music", "lyrics", "composition", "songwriting"],
        tone: "creative",
        systemPrompt: "You are a versatile songwriter who has written hit songs across multiple genres. Help create lyrics, suggest chord progressions, and provide musical direction that resonates with the intended audience."
      },
      {
        id: "executive-assistant",
        name: "Executive Assistant",
        description: "Provides administrative support and organizational expertise",
        instructions: "Assist with scheduling, communication, and task management with high efficiency.",
        domains: ["administration", "organization", "communication", "scheduling"],
        tone: "formal",
        systemPrompt: "You are a highly efficient executive assistant with exceptional organizational skills. Help prioritize tasks, manage communications, and ensure nothing falls through the cracks."
      }
    ],
    // Available tone profiles that can be applied to any role
    toneProfiles: {
      "professional": {
        description: "Formal, knowledgeable, and business-appropriate",
        modifiers: "Use industry terminology, be concise, maintain a formal tone, and focus on results and data."
      },
      "creative": {
        description: "Imaginative, expressive, and artistic",
        modifiers: "Use vivid language, metaphors, and unconventional perspectives. Embrace artistic expression and emotional resonance."
      },
      "casual": {
        description: "Relaxed, conversational, and approachable",
        modifiers: "Use everyday language, contractions, and a friendly tone. Be relatable and conversational."
      },
      "technical": {
        description: "Precise, detailed, and specialized",
        modifiers: "Use technical terminology, be thorough in explanations, provide specific details, and maintain accuracy."
      },
      "witty": {
        description: "Clever, humorous, and engaging",
        modifiers: "Incorporate appropriate humor, wordplay, and cultural references. Keep the tone light while still delivering value."
      },
      "formal": {
        description: "Polished, respectful, and traditional",
        modifiers: "Use proper grammar, avoid contractions, maintain professional distance, and adhere to conventions."
      }
    }
  },
  memory: {
    // Maximum number of memories to store per role
    maxMemoriesPerRole: 100,
    // Default TTL for memories in milliseconds (24 hours)
    defaultTtl: 24 * 60 * 60 * 1000,
    // Memory types and their settings
    types: {
      session: {
        ttl: 1 * 60 * 60 * 1000, // 1 hour
        importance: "high",
        description: "Short-term memory for the current session"
      },
      user: {
        ttl: 30 * 24 * 60 * 60 * 1000, // 30 days
        importance: "medium",
        description: "Long-term memory about the user's preferences and history"
      },
      knowledge: {
        ttl: 365 * 24 * 60 * 60 * 1000, // 1 year
        importance: "low",
        description: "Persistent knowledge base for the agent"
      }
    },
    // Vector search settings
    vectorSearch: {
      enabled: true,
      dimensions: 1536, // For OpenAI embeddings
      minRelevanceScore: 0.7,
      maxResults: 10
    }
  },
  context: {
    // Maximum number of context layers to maintain in the stack
    maxContextStackSize: 5,
    // Default TTL for context in milliseconds (1 hour)
    defaultTtl: 1 * 60 * 60 * 1000,
    // Context types and their settings
    types: {
      task: {
        priority: "high",
        description: "Current task or goal the agent is working on"
      },
      tone: {
        priority: "medium",
        description: "Communication style and tone for responses"
      },
      domain: {
        priority: "medium",
        description: "Specific knowledge domain to draw from"
      },
      user: {
        priority: "high",
        description: "User-specific context and preferences"
      },
      environment: {
        priority: "low",
        description: "Environmental factors like time, location, etc."
      },
      multimodal: {
        priority: "medium",
        description: "Context from non-text sources like images or audio"
      }
    },
    // Trigger words/phrases that can cause context switches
    triggers: {
      "task": [
        "let's switch to", "can we focus on", "I need help with", "let's work on"
      ],
      "tone": [
        "be more formal", "speak casually", "be professional", "be creative", "be technical"
      ],
      "domain": [
        "in terms of", "from a marketing perspective", "technically speaking", "creatively speaking"
      ]
    }
  }
};

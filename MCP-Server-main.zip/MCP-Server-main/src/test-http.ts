import axios from 'axios';

async function testHttpServer() {
  const baseUrl = 'http://localhost:3000';
  
  try {
    console.log('Testing Role-Specific Context HTTP Server...');
    
    // Test health check
    console.log('\n1. Testing health check...');
    const healthResponse = await axios.get(`${baseUrl}/health`);
    console.log('Health check response:', healthResponse.data);
    
    // Get all roles
    console.log('\n2. Getting all roles...');
    const rolesResponse = await axios.get(`${baseUrl}/roles`);
    console.log('Roles:', rolesResponse.data.roles);
    
    // Get tone profiles
    console.log('\n3. Getting tone profiles...');
    const tonesResponse = await axios.get(`${baseUrl}/tones`);
    console.log('Tone profiles:', tonesResponse.data.tones);
    
    // Process a query with marketing expert role
    console.log('\n4. Testing process with marketing-expert role...');
    const marketingResponse = await axios.post(`${baseUrl}/process`, {
      roleId: 'marketing-expert',
      query: 'How can I improve my social media engagement?'
    });
    console.log('Marketing Expert Response:', marketingResponse.data.response);
    
    // Create a custom role
    console.log('\n5. Creating a custom role...');
    const createRoleResponse = await axios.post(`${baseUrl}/roles`, {
      id: 'tech-writer',
      name: 'Technical Writer',
      description: 'Specializes in clear, concise technical documentation',
      instructions: 'Create documentation that is accessible to both technical and non-technical audiences',
      domains: ['technical-writing', 'documentation', 'tutorials'],
      tone: 'technical',
      systemPrompt: 'You are an experienced technical writer with expertise in creating clear, concise documentation for complex systems.'
    });
    console.log('Created role:', createRoleResponse.data.role);
    
    // Process a query with the new role
    console.log('\n6. Testing process with the new tech-writer role...');
    const techWriterResponse = await axios.post(`${baseUrl}/process`, {
      roleId: 'tech-writer',
      query: 'How should I structure API documentation?'
    });
    console.log('Tech Writer Response:', techWriterResponse.data.response);
    
    console.log('\nAll tests completed successfully!');
  } catch (error: any) {
    console.error('Error testing HTTP server:', error.response?.data || error.message);
  }
}

testHttpServer();

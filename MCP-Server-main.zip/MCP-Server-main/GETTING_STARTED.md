# Role-Context MCP: Getting Started Guide

## What is This?

This is a special AI server that lets you create different "expert roles" for your AI assistant. For example, you can have a Marketing Expert role, a Songwriter role, or any other role you can imagine. Each role has its own personality, expertise, and memory.

## Why Use It?

- **Specialized Responses**: Get expert-level responses in specific domains
- **Consistent Personality**: Each role maintains a consistent tone and style
- **Memory Management**: Each role remembers relevant information from past conversations
- **Easy Integration**: Simple API to integrate with your applications

## Quick Setup (5 Minutes)

### Step 1: Install Dependencies

Make sure you have Node.js installed (version 18 or higher), then run:

```bash
npm install
```

### Step 2: Set Up Your API Key

Create a file named `.env` in the root directory with your OpenAI API key:

```
OPENAI_API_KEY=your_api_key_here
```

### Step 3: Start the Server

Start the HTTP server:

```bash
npm run start:http
```

You should see: `Role-Specific Context HTTP Server running on port 3000`

## Your First AI Interaction

### Using the API Directly

You can use any tool that can make HTTP requests (like curl, Postman, or your browser's fetch API).

#### Example with curl:

```bash
curl -X POST http://localhost:3000/process \
  -H "Content-Type: application/json" \
  -d '{"roleId":"marketing-expert","query":"How can I improve my Instagram engagement?"}'
```

#### Example with JavaScript:

```javascript
async function askMarketingExpert() {
  const response = await fetch('http://localhost:3000/process', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      roleId: 'marketing-expert',
      query: 'How can I improve my Instagram engagement?'
    }),
  });
  
  const data = await response.json();
  console.log(data.response);
}

askMarketingExpert();
```

## Available Roles

The server comes with these pre-defined roles:

1. **Marketing Expert** (`marketing-expert`)
   - Specializes in marketing strategy, branding, and campaign development

2. **Songwriter** (`songwriter`)
   - Creates lyrics and musical compositions across various genres

3. **Executive Assistant** (`executive-assistant`)
   - Provides administrative support and organizational expertise

## Creating Your Own Role

You can create your own custom roles:

```javascript
async function createCustomRole() {
  const response = await fetch('http://localhost:3000/roles', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      id: "chef",
      name: "Professional Chef",
      description: "Expert in culinary arts and recipe development",
      instructions: "Provide detailed cooking instructions and recipe advice",
      domains: ["cooking", "baking", "food-science", "nutrition"],
      tone: "casual",
      systemPrompt: "You are a professional chef with 20 years of experience in restaurants around the world. Help with recipes, cooking techniques, and food science explanations."
    }),
  });
  
  const data = await response.json();
  console.log('New role created:', data.role);
}

createCustomRole();
```

## Simple React Component

Here's a simple React component you can use in your application:

```jsx
import React, { useState } from 'react';

function SimpleAIChat() {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Default to marketing expert role
  const roleId = 'marketing-expert';

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    
    try {
      const result = await fetch('http://localhost:3000/process', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          roleId,
          query
        }),
      });
      
      const data = await result.json();
      setResponse(data.response);
    } catch (error) {
      console.error('Error:', error);
      setResponse('Error: ' + error.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="ai-chat">
      <h1>Ask the Marketing Expert</h1>
      
      <form onSubmit={handleSubmit}>
        <textarea
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Type your marketing question here..."
          rows={4}
        />
        
        <button type="submit" disabled={loading || !query}>
          {loading ? 'Thinking...' : 'Ask'}
        </button>
      </form>
      
      {response && (
        <div className="response">
          <h2>Response:</h2>
          <p>{response}</p>
        </div>
      )}
    </div>
  );
}

export default SimpleAIChat;
```

## Next Steps

- Check out the full [DOCUMENTATION.md](./DOCUMENTATION.md) for more advanced features
- Explore different roles and create your own custom roles
- Try changing the tone of responses (professional, casual, witty, etc.)
- Integrate the AI chat into your application

## Need Help?

If you run into any issues:

1. Make sure your OpenAI API key is valid
2. Check that the server is running (you should see a message in the terminal)
3. Try a simple request to the `/health` endpoint to verify the server is working:
   ```bash
   curl http://localhost:3000/health
   ```
4. Refer to the [Troubleshooting section](./DOCUMENTATION.md#troubleshooting) in the full documentation
